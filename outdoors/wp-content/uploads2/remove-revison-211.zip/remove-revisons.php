<?php
/*
Plugin Name: Remove Revisions
Plugin URI: http://technologytales.com/
Description: Clear all revisions from database to reduce clutter
Version: 2.1.1
Author: John Hennessy
Author URI: http://technologytales.com/

License:

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110, USA
*/

function remove_revisions(){

  	global $wpdb, $_POST;

  	echo "<div class=\"wrap\">\n";
  	echo "<h2>Remove Revisions</h2>\n";

  if($_POST["remove_all"]){
  	
   	$wpdb->query("DELETE FROM $wpdb->posts where post_type='revision'");
   
   	$count=$wpdb->get_var("SELECT count(*) as count FROM $wpdb->posts where post_type='revision' ORDER BY ID");
   
   	if ($count == 0) {
?>
  <p>All of your post revisions have been removed.</p>
<?php
   }
   else {
   	?>
   	<p>None of your post revisions have been removed.</p>
<?php
   }
  }
  elseif ($_POST['remove_selected']) {
	if (isset($_POST['revisions'])) {
		$count1=$wpdb->get_var("SELECT count(*) as count FROM $wpdb->posts where post_type='revision' ORDER BY ID");
		$_i=0;
		$post_revisions=$_POST['revisions'];
		foreach ($post_revisions as $key => $value) {
			if ($value > 0) {
				$value=sprintf("%d", $value);
				$_i++;
			}
		}
		$inlist=implode(",",$post_revisions);
		$wpdb->query("DELETE FROM $wpdb->posts where ID in ($inlist)");
		$count2=$wpdb->get_var("SELECT count(*) as count FROM $wpdb->posts where post_type='revision' ORDER BY ID");
		if ($_i == 1) $rev="revision has";
		elseif ($_i > 1) $rev="revisions have";
		if ($count1  == $count2) echo "<p>The selected post $rev not been removed.</p>"; 
		else echo "<p>The selected post $rev been removed.</p>";
	}
	else {
		echo "<p>Whoops! You selected nothing to remove.</p>";
		 ?>
  <form action="<?php echo $_SERVER['PHP_SELF'];?>?page=remove-revisons.php&update=true" method="post">
    <input type="hidden" name="go-back" value="go">
    <div class="submit">
    <input type="submit" style="font-weight:bold;" value="Return to form"><br />
    </div>
  </form>
  <?php
	}
  }
  else {
?>
<?php 

	$count=$wpdb->get_var("SELECT count(*) as count FROM $wpdb->posts where post_type='revision' ORDER BY ID");

	if ($count > 0) {
?>
  <p>The one reason why Wiki's place such a load on web servers is because of their revision tracking. Now that
  WordPress has added the same sort of functionality and it is by default, clearing out the revisions in the 
  database every so often is a good idea if you don't want to turn off the functionality. Below, you can either 
  remove all revisions or only selected ones. The choice is yours.</p>
<?php
   	$sql = "SELECT * FROM $wpdb->posts where post_type='revision' ORDER BY ID";
   	$posts = $wpdb->get_results($sql);
	?>
  <form action="<?php echo $_SERVER['PHP_SELF'];?>?page=remove-revisons.php&update=true" method="post">
  <?php
if ( function_exists('wp_nonce_field') )
	wp_nonce_field('remove_all_revisions');
?>
    <input type="hidden" name="remove_all" value="go">
    <div class="submit">
    <input type="submit" style="font-weight:bold;" value="Remove All Revisions">
    </div>
  </form>
  <h3>Remove Selected Revisons</h3>
  <form action="<?php echo $_SERVER['PHP_SELF'];?>?page=remove-revisons.php&update=true" method="post" id="select_revisons">
<?php
if ( function_exists('wp_nonce_field') ) wp_nonce_field('remove_selected_revisions');
foreach ($posts as $post) {
		echo "<p><input type='checkbox' value='$post->ID' name='revisions[]' >&nbsp;$post->post_title ($post->guid)</input></p>\n";
}
?>
    <input type="hidden" name="remove_selected" value="go">
    <div class="submit" style="border: none;">
    <input type="submit" style="font-weight:bold;" value="Remove Revisions"><br />
    </div>
  </form>
  <?php
	}
	else {
		?>

  <p>The one reason why Wiki's place such a load on web servers is because of their revision tracking. Now that
  WordPress has added the same sort of functionality and it is by default, clearing out the revisions in the 
  database every so often is a good idea if you don't want to turn off the functionality. That's exactly what 
  this plugin does.</p>
  <p>However, you have no revisions so no action can be taken.</p>
  <?php
	}
  }

  print "</div>\n";
}

function add_remove_revisions_page() {
  if ( function_exists('add_management_page') && current_user_can('manage_options') ) {
    add_management_page('Remove Revisions', 'Remove Revisions', 8, basename(__FILE__), 'remove_revisions');
  }
}

add_action('admin_menu', 'add_remove_revisions_page');
?>